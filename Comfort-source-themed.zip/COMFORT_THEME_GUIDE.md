# Comfort theme update

This source package applies the Comfort visual foundation while preserving the existing Meld/Metrolist app architecture and music behavior.

## Applied in this pass
- Stable Comfort brand seed: `#6C5CE7` (indigo-violet).
- Wallpaper-derived dynamic colors are disabled so the brand palette is predictable.
- Global Material 3 surfaces are neutralized to pearl-white in light mode and soft charcoal in dark mode. Indigo remains the accent color rather than tinting every surface.
- Shared Material 3 shape tokens use softer rounded corners (10/14/20/26/32 dp) so components that use MaterialTheme shapes receive consistent rounding across screens.
- App display name is Comfort; debug display name is Comfort Debug.
- Developer name is Akhil Pal; original Meld/Metrolist attribution and GPL-3.0 references are retained.

## Important limitations
- This is a global design-system pass, not a hand-redesign of every individual Compose screen. Any component with hard-coded colors/shapes may still need screen-specific work.
- No APK was compiled or installed in this environment. Validate with JDK 21 and the Android SDK before release.
- Keep the original project license and notices when redistributing a modified build.
