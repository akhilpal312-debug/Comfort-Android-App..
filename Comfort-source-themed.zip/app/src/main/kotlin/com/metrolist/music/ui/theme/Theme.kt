/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.theme

import android.graphics.Bitmap
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.SaverScope
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.palette.graphics.Palette
import com.materialkolor.PaletteStyle
import com.materialkolor.dynamiccolor.ColorSpec
import com.materialkolor.rememberDynamicColorScheme
import com.materialkolor.score.Score

/** Comfort's stable brand seed. Keep artwork colors out of the app-wide chrome. */
val DefaultThemeColor = Color(0xFF6C5CE7)

/** Softer, more consistent corners across cards, sheets, dialogs and controls. */
private val ComfortShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun MetrolistTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    pureBlack: Boolean = false,
    themeColor: Color = DefaultThemeColor,
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    // Determine if system dynamic colors should be used (Android S+ and default theme color)
    val useSystemDynamicColor = false // Comfort: always use the Comfort indigo palette

    // Select the appropriate color scheme generation method
    val baseColorScheme = if (useSystemDynamicColor) {
        // Use standard Material 3 dynamic color functions for system wallpaper colors
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
        // Use materialKolor only when a specific seed color is provided
        rememberDynamicColorScheme(
            seedColor = themeColor, // themeColor is guaranteed non-default here
            isDark = darkTheme,
            specVersion = ColorSpec.SpecVersion.SPEC_2025,
            style = PaletteStyle.TonalSpot // Keep existing style
        )
    }

    // Apply pureBlack modification if needed, similar to original logic
    // Keep the generated indigo accents, but use a calm pearl/charcoal surface system
    // so album artwork can remain colorful without tinting every screen.
    val comfortColorScheme = remember(baseColorScheme, pureBlack, darkTheme) {
        val neutralized = if (darkTheme) {
            baseColorScheme.copy(
                background = Color(0xFF111018),
                surface = Color(0xFF17151F),
                surfaceVariant = Color(0xFF25232F),
                surfaceContainerLowest = Color(0xFF0D0C12),
                surfaceContainerLow = Color(0xFF17151F),
                surfaceContainer = Color(0xFF1C1A25),
                surfaceContainerHigh = Color(0xFF25232F),
                surfaceContainerHighest = Color(0xFF302D3B),
                outlineVariant = Color(0xFF393644),
            )
        } else {
            baseColorScheme.copy(
                background = Color(0xFFFAF9FC),
                surface = Color(0xFFFFFEFF),
                surfaceVariant = Color(0xFFF0EEF5),
                surfaceContainerLowest = Color(0xFFFFFFFF),
                surfaceContainerLow = Color(0xFFFCFBFE),
                surfaceContainer = Color(0xFFF7F5FA),
                surfaceContainerHigh = Color(0xFFF1EFF6),
                surfaceContainerHighest = Color(0xFFEAE7F1),
                outlineVariant = Color(0xFFDCD8E5),
            )
        }
        if (darkTheme && pureBlack) neutralized.pureBlack(true) else neutralized
    }

    MaterialTheme(
        colorScheme = comfortColorScheme,
        shapes = ComfortShapes,
        content = content,
    )
}

fun Bitmap.extractThemeColor(): Color = Color(
    Palette.from(this)
        .maximumColorCount(8)
        .generate()
        .rankedColors(1, DefaultThemeColor.toArgb())
        .first()
)

internal fun Palette.rankedColors(
    desiredColorCount: Int,
    fallbackColor: Int,
): List<Int> = Score.score(
    swatches.associate { it.rgb to it.population },
    desiredColorCount,
    fallbackColor,
    true,
)

fun ColorScheme.pureBlack(apply: Boolean) =
    if (apply) copy(
        surface = Color.Black,
        background = Color.Black
    ) else this

val ColorSaver = object : Saver<Color, Int> {
    override fun restore(value: Int): Color = Color(value)
    override fun SaverScope.save(value: Color): Int = value.toArgb()
}
